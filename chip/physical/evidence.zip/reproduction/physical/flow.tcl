# Fixed combinational placement/routing experiment; no resizing or logic repair.
set root $::env(CHIP_LAB)
set platform $root/physical/upstream/ORFS/flow/platforms/nangate45
set out $::env(RUN_OUTPUT)
set_thread_count 4
read_lef $platform/lef/NangateOpenCellLibrary.tech.lef
read_lef $platform/lef/NangateOpenCellLibrary.macro.mod.lef
read_liberty $root/inputs/NangateOpenCellLibrary_typical.lib
read_verilog $root/runs/pilot-002/$::env(DESIGN_VARIANT)/mapped.v
link_design design
create_clock -name virtual -period 10
set_input_transition 0.020 [all_inputs]
set_load 5.0 [all_outputs]
set_input_delay 0 -clock virtual [all_inputs]
set_output_delay 0 -clock virtual [all_outputs]
set_max_delay 10 -from [all_inputs] -to [all_outputs]
puts "MEASUREMENT_PRE_ROUTE"
report_checks -path_delay max -digits 6 -group_path_count 1
initialize_floorplan -die_area {0 0 60 60} -core_area {5 5 55 55} -site FreePDK45_38x28_10R_NP_162NW_34O
source $platform/make_tracks.tcl
place_pins -hor_layers metal3 -ver_layers metal2
global_placement -density 0.25 -skip_io
detailed_placement
check_placement -verbose
source $platform/setRC.tcl
set_routing_layers -signal metal2-metal6
set_global_routing_layer_adjustment metal2-metal6 0.3
global_route -guide_file $out/route.guide
detailed_route -output_drc $out/drc.rpt -output_maze $out/maze.log -droute_end_iter 20
write_def $out/routed.def
write_db $out/routed.odb
write_verilog $out/routed.v
extract_parasitics -ext_model_file $platform/rcx_patterns.rules
write_spef $out/routed.spef
read_spef $out/routed.spef
report_parasitic_annotation
report_design_area
puts "MEASUREMENT_POST_ROUTE"
report_checks -path_delay max -format full_clock_expanded -digits 6 -group_count 1
report_worst_slack -max
exit
