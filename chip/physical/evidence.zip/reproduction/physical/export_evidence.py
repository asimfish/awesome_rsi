from pathlib import Path
import hashlib,json,re,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'physical/runs/physical-002';SITE=ROOT.parent/'awesome_RSI/report/chip-rsi/physical';SITE.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def layout(source,out):
 text=source.read_text();units=int(re.search(r'UNITS DISTANCE MICRONS (\d+)',text)[1]);lef=(ROOT/'physical/upstream/ORFS/flow/platforms/nangate45/lef/NangateOpenCellLibrary.macro.mod.lef').read_text()
 sizes={name:(float(w),float(h)) for name,w,h in re.findall(r'MACRO\s+(\S+).*?SIZE\s+([\d.]+)\s+BY\s+([\d.]+)',lef,re.S)}
 svg=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 720 770" role="img" aria-label="Actual placed cells and routed wires from OpenROAD DEF"><rect width="720" height="770" fill="#10212a"/><text x="32" y="30" fill="#a5c9c7" font-family="monospace" font-size="12">ACTUAL DEF / 60 × 60 µm / NANGATE45</text><g transform="translate(35 695) scale(10.8 -10.8)"><rect width="60" height="60" fill="none" stroke="#58766e" stroke-width=".1"/><rect x="5" y="5" width="50" height="50" fill="none" stroke="#35545b" stroke-width=".08"/>']
 comps=text.split('COMPONENTS ',1)[1].split('END COMPONENTS')[0]
 for name,cell,x,y,orient in re.findall(r'-\s+(\S+)\s+(\S+)\s+\+ PLACED\s+\(\s*(\d+)\s+(\d+)\s*\)\s+(\w+)',comps):
  w,h=sizes[cell];svg.append(f'<rect x="{int(x)/units}" y="{int(y)/units}" width="{w}" height="{h}" fill="#d1e5ce" fill-opacity=".22" stroke="#d1e5ce" stroke-width=".035"/>')
 colors={2:'#72c4c1',3:'#bca5e9',4:'#e4b876',5:'#88bf96',6:'#d594a9'};routes=text.split('\nNETS ',1)[1].split('END NETS')[0];segments=0
 for layer,body in re.findall(r'(?:ROUTED|NEW) metal(\d+)\s+(.*?)(?=\bNEW\b|;)',routes,re.S):
  pts=re.findall(r'\(\s*([\d*]+)\s+([\d*]+)(?:\s+\d+)?\s*\)',body);last=None
  for x,y in pts:
   if (x=='*' or y=='*') and last is None:raise ValueError('Unresolved DEF wildcard')
   point=(last[0] if x=='*' else int(x)/units,last[1] if y=='*' else int(y)/units)
   if last and last!=point:
    svg.append(f'<path d="M{last[0]} {last[1]}L{point[0]} {point[1]}" fill="none" stroke="{colors.get(int(layer),"#a3aeb1")}" stroke-opacity=".58" stroke-width=".055"/>');segments+=1
   last=point
 svg.append('</g><text x="34" y="735" fill="#a5c9c7" font-family="monospace" font-size="11">Cells: pale blocks · M2: teal · M3: violet · M4–6: gold / green</text><text x="34" y="755" fill="#819b9e" font-family="monospace" font-size="10">Geometry from routed.def; wire widths simplified for readability.</text></svg>');out.write_text('\n'.join(svg));return segments
state=json.loads((RUN/'status.json').read_text());summary=[]
for result in state['results']:
 source=RUN/result['name'];out=SITE/result['name'];out.mkdir(exist_ok=True)
 log=(source/'openroad.log').read_text()
 assert 'Found 0 unannotated drivers.' in log and 'Found 0 partially unannotated drivers.' in log
 assert result['connectivity_unchanged'] and result['route_drc']==0 and result['delay_ns']>result['unrouted_same_tool_ns']
 for name in ['result.json','routed.def','routed.v','routed.spef','drc.rpt']:
  shutil.copyfile(source/name,out/name)
 (out/'openroad.log').write_text(log.replace(str(ROOT),'/lab/chip'))
 if result['repeat']==1:summary.append({'name':result['name'],'segments_drawn':layout(source/'routed.def',out/'layout.svg')})
platform=ROOT/'physical/upstream/ORFS/flow/platforms/nangate45'
manifest={'openroad':json.loads((ROOT/'physical/packages/provenance.json').read_text()),'orfs_commit':'256c560888957814114e718cdb83c4b4eba6cd7d','flow_sha256':sha(ROOT/'physical/flow.tcl'),'inputs':{str(p.relative_to(ROOT)):sha(p) for p in [ROOT/'inputs/NangateOpenCellLibrary_typical.lib',platform/'lef/NangateOpenCellLibrary.tech.lef',platform/'lef/NangateOpenCellLibrary.macro.mod.lef',platform/'rcx_patterns.rules']},'layout_exports':summary,'parasitics_annotation':'All six logs: 0 unannotated / 0 partially unannotated drivers','comparison':'OpenROAD integrated STA same version for unrouted and routed values; two identical-settings reruns, not a multi-seed study.'}
(SITE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
shutil.copyfile(ROOT/'monitoring/research.json',SITE/'research.json')
with zipfile.ZipFile(SITE/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in SITE.rglob('*'):
  if p.is_file() and p.name!='evidence.zip':z.write(p,p.relative_to(SITE))
 for p in [ROOT/'physical/flow.tcl',ROOT/'scripts/run_physical.py',Path(__file__),ROOT/'physical/packages/provenance.json']:
  z.write(p,'reproduction/'+str(p.relative_to(ROOT)))
 for variant in ['baseline','seed','candidate-03']:
  for name in ['mapped.v','mapped-proof.json','mapped-formal.log']:
   p=ROOT/'runs/pilot-002'/variant/name
   if p.exists():z.write(p,'reproduction/runs/pilot-002/'+variant+'/'+name)
  p=ROOT/'runs/pilot-002'/variant/'result.json';z.write(p,'reproduction/runs/pilot-002/'+variant+'/result.json')
 for name in ['lef/NangateOpenCellLibrary.tech.lef','lef/NangateOpenCellLibrary.macro.mod.lef','rcx_patterns.rules','make_tracks.tcl','setRC.tcl','LICENSE']:
  p=platform/name;z.write(p,'reproduction/'+str(p.relative_to(ROOT)))
 z.write(ROOT/'inputs/NangateOpenCellLibrary_typical.lib','reproduction/inputs/NangateOpenCellLibrary_typical.lib')
 z.write(platform/'LICENSE','inputs/Nangate45-LICENSE');z.write(ROOT/'inputs/COPYING','inputs/verilog-axis-COPYING')
print('Physical evidence exported',summary)
