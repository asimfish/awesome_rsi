# Kernel Loop：真实算子优化实验

PyTorch 2.7.0+cu128 / Triton 3.3.0 / RTX 5090。来源 KernelBench commit 423217d9fda91e0c2d67e4a43bf62f96f6d104f1，inputs保留原始文件与MIT许可证。仅使用Model.forward，未调用上游巨大规模get_inputs。本项目为助手编写候选的有界研究。

## 复跑

在有匹配CUDA环境的新目录解压证据包。单候选例子：

```bash
CUDA_VISIBLE_DEVICES=1 python scripts/evaluate_kernel.py softmax kernels/warps16.py runs/my-retest
```

输入及计时协议固定在scripts/evaluate_kernel.py。若仅有单卡，将CUDA_VISIBLE_DEVICES设置为0，并注意GPU快照函数目前固定查询物理GPU1；移植时需一并修改并记录环境差异。GPU共享负载不是受控条件。

完整有界控制器：`python scripts/run_research.py`。固定GPU1、每子进程600秒、最多约1.5GiB PyTorch内存。控制器会写runs/kernel-002，所以复跑请在新目录进行，保留原始证据。

状态从runs/kernel-002/status.json读取；原始结果包含每组计时、正确性、源码SHA256及工具版本。性能单位微秒。CUDA Graph计时不包含Python调用和分配，不能当作端到端应用加速。
