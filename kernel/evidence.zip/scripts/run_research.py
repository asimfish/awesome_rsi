"""Bounded sequential research controller. Publishes only reviewed measurement summaries."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'runs/kernel-002'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
state={'schema':1,'project':'kernel','run_id':'kernel-002','state':'running','started_at':now(),'updated_at':now(),'stage':'baseline','current':'','completed':0,'planned':12,'results':[],'events':[],
 'scope':'KernelBench 原始 forward + 自定义规模；FP32 连续二维输入；CUDA Graph 设备计时；共享 RTX 5090；非官方榜单分数。',
 'method':'研究者编写 Triton 候选，按测量反馈单变量迭代；本轮未启动自主模型搜索。',
 'next':'对通过正确性验证的候选复测，再扩展隐藏形状与独立搜索对照。'}
def save(event=None):
 state['updated_at']=now()
 if event:state['events'].append({'at':now(),'text':event})
 RUN.mkdir(parents=True,exist_ok=True)
 tmp=RUN/'status.tmp';tmp.write_text(json.dumps(state,ensure_ascii=False,indent=2));tmp.replace(RUN/'status.json')
def run(op,name,profile=False):
 state.update(current=op+'/'+name);save('开始 '+state['current'])
 out=RUN/op/name;out.mkdir(parents=True,exist_ok=True)
 source=ROOT/'kernels'/((name if name!='retest' else state['selected'][op])+'.py')
 (out/'candidate.py').write_bytes(source.read_bytes())
 args=[sys.executable,str(ROOT/'scripts/evaluate_kernel.py'),op,str(out/'candidate.py'),str(out)]
 if profile:args.append('--profile')
 env=dict(os.environ,CUDA_VISIBLE_DEVICES='1',TORCHINDUCTOR_CACHE_DIR=str(ROOT/'runs/compiler-cache'),TRITON_CACHE_DIR=str(ROOT/'runs/triton-cache'),OMP_NUM_THREADS='4',TORCHINDUCTOR_COMPILE_THREADS='2')
 try:
  with (out/'console.log').open('w') as f:
   p=subprocess.Popen(args,stdout=f,stderr=subprocess.STDOUT,env=env,start_new_session=True)
   start=time.monotonic()
   while p.poll() is None:
    if time.monotonic()-start>600:
     import signal;os.killpg(p.pid,signal.SIGKILL);p.wait();raise TimeoutError('600-second budget')
    time.sleep(3);save()
  result=json.loads((out/'result.json').read_text())
 except Exception as e:result={'state':'failed','reason':type(e).__name__,'measurements':[]}
 result.update(operator=op,candidate=name,artifact='evidence/'+op+'/'+name+'/result.json')
 state['results'].append(result);state['completed']+=1;save('完成 '+op+'/'+name+' · '+result['state'])
 print(op,name,result['state'],flush=True)
 return result
try:
 save('冻结 v2 计时协议；先完成三个朴素基线')
 for op in ['relu','softmax','gelu']:run(op,'naive',True)
 state['stage']='optimization';save('基线完成：pointwise 增大块，softmax 单独调整 warps')
 for op in ['relu','gelu']:
  for name in ['block256','block1024']:run(op,name)
 for name in ['warps8','warps16']:run('softmax',name)
 state.update(stage='retest',selected={})
 for op in ['relu','softmax','gelu']:
  valid=[r for r in state['results'] if r['operator']==op and r['state']=='completed']
  if not valid:continue
  best=max(valid,key=lambda r:sum(__import__('math').log(m['speedup_vs_compiled']) for m in r['measurements']))
  state['selected'][op]=best['candidate'];run(op,'retest')
 state.update(state='completed',stage='review',current='',next='复测已完成；下一步扩展独立尺寸验证与形状分派，再做固定预算的有/无经验记忆搜索对照。');save('本轮有界实验完成；结果是否稳定以逐形状复测为准')
except Exception as e:
 state.update(state='failed',reason=type(e).__name__,current='');save('控制器中断；保留已完成结果');raise
