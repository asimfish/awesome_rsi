from pathlib import Path
import json,shutil,zipfile,hashlib
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT.parent/'awesome_RSI/report/kernel-rsi';RUN=ROOT/'runs/kernel-002'
SITE.mkdir(parents=True,exist_ok=True);s=json.loads((RUN/'status.json').read_text())
assert len(s['results'])==12 and all(r['state']=='completed' and r['correctness']['pass'] and r['correctness']['negative_control_rejected'] for r in s['results'])
for r in s['results']:
 source=RUN/r['operator']/r['candidate'];out=SITE/'evidence'/r['operator']/r['candidate'];out.mkdir(parents=True,exist_ok=True)
 for name in ['result.json','candidate.py','profile.txt']:
  p=source/name
  if p.exists():shutil.copyfile(p,out/name)
 assert hashlib.sha256((out/'candidate.py').read_bytes()).hexdigest()==r['candidate_sha256']
shutil.copyfile(ROOT/'GOAL.md',SITE/'protocol.md');shutil.copyfile(ROOT/'notes/perf_log.md',SITE/'results.md')
shutil.copyfile(ROOT.parent/'rsi-chip-lab/monitoring/research.json',SITE/'research.json')
with zipfile.ZipFile(SITE/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['scripts','kernels','inputs','notes']:
  for p in (ROOT/folder).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts:z.write(p,p.relative_to(ROOT))
 for run in ['kernel-001','calibration-v2','kernel-002']:
  for p in (ROOT/'runs'/run).rglob('*'):
   if p.is_file() and p.name in ['result.json','status.json','candidate.py','profile.txt']:z.write(p,p.relative_to(ROOT))
 z.write(ROOT/'GOAL.md','GOAL.md');z.write(ROOT/'README.md','README.md')
print('Exported 12 runs, 24 shape measurements and source hashes')
