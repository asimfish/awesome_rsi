"""Frozen correctness and paired GPU timing; executes only reviewed local candidate paths."""
from pathlib import Path
import argparse,copy,hashlib,importlib.util,json,os,random,statistics,subprocess,time
import torch
import triton
ROOT=Path(__file__).resolve().parents[1]
TASKS={'relu':('19_ReLU.py',[(1024,1024),(4096,4096)]),'softmax':('23_Softmax.py',[(256,1024),(1024,4096)]),'gelu':('88_MinGPTNewGelu.py',[(1024,1024),(2048,4096)])}

def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def gpu_snapshot():
    r=subprocess.run(['nvidia-smi','--id=1','--query-gpu=name,utilization.gpu,memory.used,temperature.gpu,power.draw,clocks.sm','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10)
    return r.stdout.strip()

def stats(values):
    return {'median_us':statistics.median(values),'min_us':min(values),'max_us':max(values),'stdev_us':statistics.stdev(values) if len(values)>1 else 0,'samples_us':values}

def prepare_timing(fn,x):
    stream=torch.cuda.Stream();stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(stream):
        for _ in range(3):fn(x)
    torch.cuda.current_stream().wait_stream(stream)
    graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        for _ in range(30):y=fn(x)
    for _ in range(3):graph.replay()
    torch.cuda.synchronize()
    return graph,y

def timed(prepared):
    graph,y=prepared
    torch.cuda.synchronize()
    start=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True)
    start.record()
    for _ in range(10):graph.replay()
    end.record();end.synchronize()
    return start.elapsed_time(end)*1000/300

def correctness(fn,reference,op):
    tests=[];worst=0.0
    for shape in [(0,33),(1,1),(7,33),(17,127),(32,1024),(2,4097)]:
        for seed in [101,202,303]:
            torch.manual_seed(seed);x=torch.randn(shape,device='cuda',dtype=torch.float32)* (30 if seed==303 else 1)
            if seed==202:x.zero_()
            before=x.clone();expected=reference(x);got=fn(x);torch.cuda.synchronize()
            torch.testing.assert_close(got,expected,rtol=1e-4,atol=1e-5,check_dtype=True)
            if got.shape!=expected.shape or not torch.equal(x,before):raise AssertionError('Output shape or input mutation')
            error=float((got-expected).abs().max()) if got.numel() else 0.0;worst=max(worst,error)
            tests.append({'shape':list(shape),'seed':seed,'max_abs_error':error,'pass':True})
    # Negative control proves the checker rejects incorrect outputs.
    x=torch.ones((7,33),device='cuda');expected=reference(x)
    try:torch.testing.assert_close(torch.zeros_like(expected),expected,rtol=1e-4,atol=1e-5)
    except AssertionError:negative=True
    else:raise AssertionError('Incorrect-output negative control not rejected')
    return {'pass':True,'cases':tests,'max_abs_error':worst,'negative_control_rejected':negative,'rtol':1e-4,'atol':1e-5}

def evaluate(op,candidate,output,profile=False):
    output.mkdir(parents=True,exist_ok=True);reference=load(ROOT/'inputs'/TASKS[op][0],op+'_reference').Model().cuda().eval()
    module=load(candidate,'candidate_'+op+'_'+candidate.stem);fn=lambda x:module.run(x,op)
    result={'operator':op,'candidate':candidate.stem,'candidate_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'state':'running','gpu_before':gpu_snapshot(),'torch':torch.__version__,'triton':triton.__version__,'cuda':torch.version.cuda,'gpu':torch.cuda.get_device_name(0),'timing_protocol':'v2-cuda-graph-30-ops-x10-replays-7-rotated-pairs','scope':'custom shapes, FP32 contiguous; shared GPU; CUDA Graph device execution, excludes Python launch and allocation; not official KernelBench score'}
    start=time.monotonic()
    try:
        torch.cuda.set_per_process_memory_fraction(.045,0)
        with torch.no_grad():
            result['correctness']=correctness(fn,reference,op)
            compiled=torch.compile(reference,fullgraph=True)
            result['measurements']=[]
            for shape in TASKS[op][1]:
                torch.manual_seed(991);x=torch.randn(shape,device='cuda')
                torch.testing.assert_close(fn(x),reference(x),rtol=1e-4,atol=1e-5)
                torch.testing.assert_close(compiled(x),reference(x),rtol=1e-4,atol=1e-5)
                for f in [reference,compiled,fn]:
                    for _ in range(10):f(x)
                torch.cuda.synchronize()
                if profile and shape==TASKS[op][1][0]:
                    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]) as prof:
                        for _ in range(3):reference(x)
                        torch.cuda.synchronize()
                    (output/'profile.txt').write_text(prof.key_averages().table(sort_by='self_cuda_time_total',row_limit=16))
                samples={k:[] for k in ['eager','compiled','candidate']};functions={'eager':reference,'compiled':compiled,'candidate':fn}
                prepared={key:prepare_timing(func,x) for key,func in functions.items()}
                for trial in range(7):
                    order=list(functions);order=order[trial%3:]+order[:trial%3]
                    for key in order:samples[key].append(timed(prepared[key]))
                summary={key:stats(val) for key,val in samples.items()}
                med=summary['candidate']['median_us'];e=summary['eager']['median_us'];c=summary['compiled']['median_us']
                summary.update(shape=list(shape),speedup_vs_eager=e/med,speedup_vs_compiled=c/med,stable=all(s['stdev_us']/s['median_us']<.15 for s in summary.values() if isinstance(s,dict)))
                result['measurements'].append(summary)
                del prepared
                print(op,candidate.stem,shape,'candidate us',round(med,3),'eager speedup',round(e/med,3),'compiled',round(c/med,3),flush=True)
        result['state']='completed'
    except Exception as e:
        result.update(state='failed',reason=type(e).__name__+': '+str(e)[:2500])
    result['gpu_after']=gpu_snapshot();result['elapsed_s']=round(time.monotonic()-start,2)
    (output/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));return result

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('operator',choices=TASKS);a.add_argument('candidate');a.add_argument('output');a.add_argument('--profile',action='store_true');args=a.parse_args()
    r=evaluate(args.operator,Path(args.candidate).resolve(),Path(args.output).resolve(),args.profile);print(r['state'],r.get('reason',''),flush=True)
    raise SystemExit(0 if r['state']=='completed' else 1)
