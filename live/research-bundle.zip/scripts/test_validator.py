import unittest
from evaluate import validate_rtl
class ValidatorTests(unittest.TestCase):
 def test_sensitivity_star_is_not_attribute(self):
  validate_rtl('module design(input a, output reg b); always @(*) b=a; endmodule')
 def test_attribute_is_blocked(self):
  with self.assertRaises(ValueError):validate_rtl('(* blackbox *) module design(); endmodule')
 def test_external_file_is_blocked(self):
  with self.assertRaises(ValueError):validate_rtl('`include "private"\nmodule design(); endmodule')
 def test_unknown_output_is_blocked(self):
  with self.assertRaises(ValueError):validate_rtl("module design(output a); assign a=1'bx; endmodule")
if __name__=='__main__':unittest.main()
