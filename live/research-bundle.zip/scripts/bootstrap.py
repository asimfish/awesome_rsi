"""Retrieve hash-pinned official library and extract version-pinned Debian tools."""
from pathlib import Path
import hashlib,json,subprocess,urllib.request
ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'runs/pilot-002/manifest.json').read_text())
provenance=json.loads((ROOT/'inputs/provenance.json').read_text())
for name,meta in provenance.items():
 p=ROOT/'inputs'/name
 expected=manifest['input_hashes'][name]
 if not p.exists():
  content=urllib.request.urlopen(meta['url'],timeout=60).read()
  if hashlib.sha256(content).hexdigest()!=expected:raise SystemExit('Source hash mismatch: '+name)
  p.write_bytes(content)
 if hashlib.sha256(p.read_bytes()).hexdigest()!=expected:raise SystemExit('Input hash mismatch: '+name)
checks=json.loads((ROOT/'toolchain/packages/sha256.json').read_text())
for name,expected in checks.items():
 p=ROOT/'toolchain/packages'/name
 if not p.exists():raise SystemExit('Download the pinned Debian package listed in README: '+name)
 if hashlib.sha256(p.read_bytes()).hexdigest()!=expected:raise SystemExit('Package hash mismatch: '+name)
 subprocess.run(['dpkg-deb','-x',str(p),str(ROOT/'toolchain')],check=True)
print('Pinned inputs and toolchain ready')
