"""Read-only Linux telemetry. Output is an explicit public field allowlist."""
import csv,datetime,json,os,re,shutil,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def cpu_times():
 v=list(map(int,Path('/proc/stat').read_text().splitlines()[0].split()[1:9]));return sum(v),v[3]+v[4]
def number(s):
 try:return float(s)
 except (ValueError,TypeError):return None

def project_processes():
 parents={};direct={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   stat=(p/'stat').read_text().rsplit(') ',1)[1].split();parents[int(p.name)]=(int(stat[1]),stat[0])
   if p.stat().st_uid!=os.getuid():continue
   args=(p/'cmdline').read_bytes()[:8192].decode(errors='replace').split('\0')
   for arg in args[1:]:
    # Only trusted local research entrypoints are labelled; never emit cmdlines/PIDs.
    if re.fullmatch(r'run_pilot(?:_v\d+)?\.py|evaluate(?:_v\d+)?\.py|probe_grouped\.py',Path(arg).name):
     resolved=Path(arg) if Path(arg).is_absolute() else Path(os.readlink(p/'cwd'))/arg
     if resolved.resolve().parent==ROOT/'scripts' and stat[0]!='Z':
      direct[int(p.name)]='优化控制器' if Path(arg).name.startswith('run_') else 'EDA 验证';break
  except (OSError,ValueError,IndexError):continue
 active=set(direct)
 for _ in range(12):
  kids={pid for pid,(ppid,state) in parents.items() if ppid in active and state!='Z'}
  if kids<=active:break
  active|=kids
 counts={label:list(direct.values()).count(label) for label in sorted(set(direct.values()))}
 return active,[{'label':k,'count':v} for k,v in counts.items()]

def gpu_metrics(project_pids):
 if not shutil.which('nvidia-smi'):return {'status':'unavailable','reason':'未检测到 NVIDIA 工具','cards':[]}
 try:
  q='index,uuid,name,utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw,power.limit'
  r=subprocess.run(['nvidia-smi','--query-gpu='+q,'--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10)
  if r.returncode:return {'status':'unavailable','reason':'GPU 采集失败','cards':[]}
  procs={};process_ok=False
  try:
   a=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,used_memory','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10)
   process_ok=a.returncode==0
   if process_ok:
    for row in csv.reader(a.stdout.splitlines()):
     if len(row)!=3:continue
     uuid,pid,mem=[x.strip() for x in row]
     if pid.isdigit():procs.setdefault(uuid,[]).append(int(pid) in project_pids)
  except subprocess.TimeoutExpired:pass
  cards=[]
  for row in csv.reader(r.stdout.splitlines()):
   if len(row)!=9:raise ValueError('GPU schema')
   idx,uuid,name,util,used,total,temp,power,limit=[x.strip() for x in row];ps=procs.get(uuid,[])
   cards.append({'index':int(idx),'model':name[:100],'util_pct':number(util),'memory_used_mib':number(used),'memory_total_mib':number(total),'temperature_c':number(temp),'power_w':number(power),'power_limit_w':number(limit),'project_compute_processes':sum(ps) if process_ok else None,'other_compute_processes':len(ps)-sum(ps) if process_ok else None})
  return {'status':'ok','cards':cards}
 except (OSError,ValueError,subprocess.TimeoutExpired):return {'status':'unavailable','reason':'GPU 采集超时或数据不可用','cards':[]}

def collect():
 begin=cpu_times();time.sleep(1);end=cpu_times();delta=end[0]-begin[0]
 cpu_pct=round(100*(1-(end[1]-begin[1])/delta),1) if delta>0 else None
 mem={k:int(v.split()[0])*1024 for k,v in (line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())}
 total=mem['MemTotal'];used=total-mem['MemAvailable'];cpu_model=next((line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),'CPU')
 disks=[]
 for label,path in [('系统盘',Path('/')),('实验存储',ROOT)]:
  try:
   d=os.statvfs(path);size=d.f_blocks*d.f_frsize;u=(d.f_blocks-d.f_bfree)*d.f_frsize;avail=d.f_bavail*d.f_frsize
   disks.append({'label':label,'total_bytes':size,'used_bytes':u,'available_bytes':avail,'used_pct':round(100*u/(u+avail),1) if u+avail else None})
  except OSError:disks.append({'label':label,'status':'unavailable'})
 pids,labels=project_processes();gpus=gpu_metrics(pids);runs=[]
 for p in sorted((ROOT/'runs').glob('pilot-*/status.json')):
  try:
   r=json.loads(p.read_text());runid=r['run_id']
   if not re.fullmatch(r'pilot-\d{3}',runid):continue
   runs.append({'run_id':runid,'state':r['state'] if r['state'] in ['running','completed','failed'] else 'unknown','stage':str(r['stage'])[:40],'completed':int(r['completed']),'budget':int(r['budget']),'updated_at':r['updated_at']})
  except (ValueError,OSError,KeyError,TypeError):continue
 return {'schema':1,'updated_at':now(),'collection_interval_s':300,'stale_after_s':900,'node':{'label':'RSI 实验节点','cpu':{'model':cpu_model,'logical_cpus':os.cpu_count(),'util_pct':cpu_pct,'sample_seconds':1,'load':list(os.getloadavg())},'memory':{'total_bytes':total,'used_bytes':used,'available_bytes':mem['MemAvailable'],'used_pct':round(100*used/total,1),'swap_total_bytes':mem['SwapTotal'],'swap_used_bytes':mem['SwapTotal']-mem['SwapFree']},'disks':disks,'uptime_seconds':int(float(Path('/proc/uptime').read_text().split()[0])),'gpus':gpus},'project':{'active_process_count':len(pids),'tasks':labels,'runs':runs,'note':'资源指标为整机共享资源；任务标签仅标识本项目。模型通过远程 API 调用，当前 RTL 评估使用 CPU。'}}

if __name__=='__main__':print(json.dumps(collect(),ensure_ascii=False,indent=2))
