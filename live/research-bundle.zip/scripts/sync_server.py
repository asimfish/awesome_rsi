"""One bounded telemetry collection/upload; systemd timer schedules it independently of experiments."""
import argparse,base64,fcntl,json,os,subprocess,urllib.error,urllib.request
from pathlib import Path
from collect_server import collect,ROOT
STATE=ROOT/'monitoring';API='https://api.github.com/repos/asimfish/awesome_rsi';BRANCH='server-data'

def api(path,token,method='GET',payload=None):
 req=urllib.request.Request(API+path,data=None if payload is None else json.dumps(payload).encode(),method=method,headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'silicon-loop-server-monitor'})
 with urllib.request.urlopen(req,timeout=20) as r:return json.load(r)

def validate(s):
 # Explicit public contract: excludes hostname, IP, UUID, usernames, PIDs, command lines and env.
 assert set(s)=={'schema','updated_at','collection_interval_s','stale_after_s','node','project','history'}
 assert set(s['node'])=={'label','cpu','memory','disks','uptime_seconds','gpus'}
 assert len(s['history'])<=36
 assert set(s['project'])=={'active_process_count','tasks','runs','note'}
 for c in s['node']['gpus']['cards']:
  assert set(c)=={'index','model','util_pct','memory_used_mib','memory_total_mib','temperature_c','power_w','power_limit_w','project_compute_processes','other_compute_processes'}

def main():
 p=argparse.ArgumentParser();p.add_argument('--publish',action='store_true');p.add_argument('--init-branch',action='store_true');a=p.parse_args();STATE.mkdir(exist_ok=True)
 with (STATE/'collector.lock').open('w') as lock:
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:print('Collector already active; skipped');return
  s=collect();old=STATE/'servers.json'
  try:history=json.loads(old.read_text()).get('history',[])
  except (OSError,ValueError):history=[]
  sample={'at':s['updated_at'],'cpu_pct':s['node']['cpu']['util_pct'],'memory_pct':s['node']['memory']['used_pct'],'gpu_pct':[c['util_pct'] for c in s['node']['gpus']['cards']]}
  # Retain at most one point per five-minute window; manual checks do not flood the chart.
  from datetime import datetime
  if history and datetime.fromisoformat(sample['at']).timestamp()-datetime.fromisoformat(history[-1]['at']).timestamp()<240:history[-1]=sample
  else:history.append(sample)
  s['history']=history[-36:];validate(s)
  content=json.dumps(s,ensure_ascii=False,indent=2).encode();tmp=STATE/'servers.tmp';tmp.write_bytes(content);tmp.replace(old)
  if not a.publish:print('Collected public server metrics');return
  cred=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\n\n',capture_output=True,text=True,check=True,timeout=10,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'))
  fields=dict(line.split('=',1) for line in cred.stdout.splitlines() if '=' in line);token=fields['password']
  if a.init_branch:
   try:api('/git/ref/heads/'+BRANCH,token)
   except urllib.error.HTTPError as e:
    if e.code!=404:raise
    base=api('/git/ref/heads/gh-pages',token)['object']['sha'];api('/git/refs',token,'POST',{'ref':'refs/heads/'+BRANCH,'sha':base})
  try:existing=api('/contents/servers.json?ref='+BRANCH,token)
  except urllib.error.HTTPError as e:
   if e.code!=404:raise
   existing={}
  if existing.get('content'):
   previous=json.loads(base64.b64decode(existing['content']))
   if previous.get('schema')!=1 or previous.get('node',{}).get('label')!='RSI 实验节点':raise ValueError('Refusing to overwrite unrelated data')
  body={'message':'[monitor/data]: update server resource snapshot','content':base64.b64encode(content).decode(),'branch':BRANCH}
  if existing.get('sha'):body['sha']=existing['sha']
  result=api('/contents/servers.json',token,'PUT',body)
  (STATE/'last-publish.json').write_text(json.dumps({'sample_at':s['updated_at'],'commit':result['commit']['sha']},indent=2))
  print('Published server snapshot '+s['updated_at'])
if __name__=='__main__':
 try:main()
 except Exception as e:
  # Never print HTTP bodies, authentication headers, credential helper output or process args.
  print('Server telemetry failed: '+type(e).__name__);raise SystemExit(1)
