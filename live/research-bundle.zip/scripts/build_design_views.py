"""Extract original mapped netlists and STA paths; no synthesis or metric changes."""
import collections,hashlib,json,re,shutil,subprocess
from pathlib import Path
from evaluate import ROOT,run_tool
SITE=ROOT.parent/'awesome_RSI/report/chip-rsi';OUT=SITE/'assets/design';OUT.mkdir(exist_ok=True)
configs={'baseline':('baseline','原始设计'),'seed':('seed','研究者种子'),'winner':('candidate-03','RSI 模型候选 C03')}
all_data={'schema':1,'run_id':'pilot-002','designs':{}}
for key,(folder,label) in configs.items():
 src=ROOT/'runs/pilot-002'/folder;work=ROOT/'visualization'/key;work.mkdir(exist_ok=True)
 shutil.copyfile(src/'mapped.v',work/'mapped.v')
 (work/'read.ys').write_text('read_liberty -lib /inputs/NangateOpenCellLibrary_typical.lib\nread_verilog mapped.v\nhierarchy -check -top design\nwrite_json view-netlist.json\n')
 code,log,_=run_tool(work,'/toolchain/usr/bin/yosys',['-s','read.ys'],'read-netlist');assert code==0,log[-1000:]
 m=json.loads((work/'view-netlist.json').read_text())['modules']['design'];result=json.loads((src/'result.json').read_text());assert len(m['cells'])==result['cells']
 timing=(src/'timing.log').read_text();start=re.search(r'^Startpoint: (\S+)',timing,re.M)[1];end=re.search(r'^Endpoint: (\S+)',timing,re.M)[1]
 path=[]
 for line in timing.splitlines():
  match=re.match(r'\s*([\d.]+)\s+([\d.]+)\s+([v^])\s+(\w+)/(\w+)\s+\((\w+)\)',line)
  if match:
   delay,arrival,transition,cell,pin,typ=match.groups();assert m['cells'][cell]['type']==typ
   path.append({'cell':cell,'type':typ,'pin':pin,'delay_ps':float(delay)*1000,'arrival_ps':float(arrival)*1000,'transition':'rise' if transition=='^' else 'fall'})
 assert path and abs(float(re.search(r'^\s+([\d.]+)\s+data arrival time',timing,re.M)[1])-result['delay_ns'])<1e-8
 nodes=[];drivers={};sinks=collections.defaultdict(list)
 for port,p in m['ports'].items():
  for i,bit in enumerate(p['bits']):
   name=port if len(p['bits'])==1 else f'{port}[{i}]';nid='port:'+name
   nodes.append({'id':nid,'label':name,'kind':p['direction']})
   if p['direction']=='input':assert bit not in drivers;drivers[bit]=nid
   else:sinks[bit].append(nid)
 for name,c in m['cells'].items():
  nodes.append({'id':name,'label':name+'\n'+c['type'],'kind':'cell','type':c['type']})
  for port,bits in c['connections'].items():
   direction=c['port_directions'][port]
   for bit in bits:
    if direction=='output':assert bit not in drivers;drivers[bit]=name
    else:sinks[bit].append(name)
 edges=set()
 for bit,targets in sinks.items():
  if bit not in drivers:
   assert isinstance(bit,str) and bit in '01';drivers[bit]='constant:'+bit
   if not any(n['id']==drivers[bit] for n in nodes):nodes.append({'id':drivers[bit],'label':bit,'kind':'constant'})
  edges.update((drivers[bit],target) for target in targets)
 critical=['port:'+start]+[p['cell'] for p in path]+['port:'+end];critical_edges=set(zip(critical,critical[1:]));assert critical_edges<=edges,(key,critical_edges-edges)
 ids={n['id']:'n'+str(i) for i,n in enumerate(nodes)}
 lines=['digraph chip {','graph [rankdir=LR, bgcolor="#091213", pad="0.35", nodesep="0.10", ranksep="0.50", splines=polyline, label="'+label+' | '+str(len(m['cells']))+' cells | connectivity graph, NOT physical layout", fontcolor="#a3eece", fontsize=18];','node [shape=box, style="rounded,filled", color="#3a5550", fillcolor="#142324", fontcolor="#b9cfca", fontname="Arial", fontsize=9, margin="0.07,0.05"];','edge [color="#2b4942", arrowsize=0.35, penwidth=0.6];']
 for n in nodes:
  hot=n['id'] in critical;attrs={'label':n['label'],'id':'net-'+ids[n['id']],'tooltip':n['label'].replace('\n',' · '),'class':'critical' if hot else 'context'}
  if n['kind']!='cell':attrs['shape']='oval'
  if hot:attrs.update(color='#a3eece',fillcolor='#285344',fontcolor='#e7fff3',penwidth='2')
  lines.append(ids[n['id']]+' ['+', '.join(k+'='+json.dumps(v) for k,v in attrs.items())+'];')
 for a,b in sorted(edges):
  hot=(a,b) in critical_edges;attrs='color="#a3eece",penwidth=2.4,class="critical-edge"' if hot else 'class="context-edge"'
  lines.append(ids[a]+' -> '+ids[b]+' ['+attrs+'];')
 lines.append('}');(work/'netlist.dot').write_text('\n'.join(lines));subprocess.run(['dot','-Tsvg',str(work/'netlist.dot'),'-o',str(OUT/(key+'-netlist.svg'))],check=True,timeout=30)
 mapped_source=(src/'mapped.v').read_text()
 for node in nodes:
  node['svg_id']='net-'+ids[node['id']]
  node['critical']=node['id'] in critical
  if node['kind']=='cell':
   match=re.search(r'\b'+re.escape(node['type'])+r'\s+'+re.escape(node['id'])+r'\s*\([\s\S]*?\);',mapped_source)
   assert match,node['id']
   node['source']=match[0]
 data={'label':label,'folder':folder,'metrics':result,'source_sha256':hashlib.sha256((src/'candidate.v').read_bytes()).hexdigest(),'mapped_sha256':hashlib.sha256((src/'mapped.v').read_bytes()).hexdigest(),'source':(src/'candidate.v').read_text(),'path':{'start':start,'end':end,'cells':path,'total_ps':result['delay_ns']*1000},'cell_types':dict(collections.Counter(c['type'] for c in m['cells'].values())),'netlist':{'cells':len(m['cells']),'nodes':len(nodes),'edges':len(edges),'critical_nodes':[ids[x] for x in critical],'svg':key+'-netlist.svg','node_details':nodes},'evidence_base':'live/runs/pilot-002/artifacts/'+folder+'/'}
 all_data['designs'][key]=data
 (work/'graph.json').write_text(json.dumps({'nodes':nodes,'edges':sorted(edges),'critical':critical},indent=2))
(OUT/'design-data.json').write_text(json.dumps(all_data,ensure_ascii=False,indent=2));(OUT/'design-data.js').write_text('window.CHIP_DESIGNS = '+json.dumps(all_data,ensure_ascii=False)+';\n')
print({k:{'cells':d['netlist']['cells'],'edges':d['netlist']['edges'],'path_cells':len(d['path']['cells']),'delay_ps':d['path']['total_ps']} for k,d in all_data['designs'].items()})
