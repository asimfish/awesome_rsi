"""Bounded post-route comparison; preserves original pilot results."""
import datetime,hashlib,json,os,re,signal,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'physical/runs/physical-002'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def graph(path):
 s=path.read_text();cells={}
 for typ,name,body in re.findall(r'\b(\w+_X\d+)\s+(\w+)\s*\((.*?)\);',s,re.S):
  cells[name]=(typ,sorted((pin,re.sub(r'[\s\\]','',net)) for pin,net in re.findall(r'\.(\w+)\s*\((.*?)\)',body)))
 assigns=sorted(re.sub(r'[\s\\]','',a) for a in re.findall(r'assign\s+(.*?);',s,re.S))
 return {'cells':cells,'assigns':assigns}
state={'schema':1,'project':'chip','run_id':'physical-002','state':'running','stage':'placement-routing','current':'','started_at':now(),'updated_at':now(),'completed':0,'planned':6,'results':[],'events':[],
 'scope':'Nangate45 TT；相同 60×60 µm die / 50×50 µm core；固定映射单元，无重综合；OpenROAD 布局、详细布线、OpenRCX 寄生提取。未做晶圆厂签核或功耗分析。',
 'method':'原始基线、研究者种子、C03 各运行两次；与同版本工具的无布线时序对照。',
 'next':'据布线后结果修订优化目标，再开展跨模块与独立轨迹对照。'}
def save(event=None):
 state['updated_at']=now()
 if event:state['events'].append({'at':now(),'text':event})
 RUN.mkdir(parents=True,exist_ok=True);p=RUN/'status.tmp';p.write_text(json.dumps(state,ensure_ascii=False,indent=2));p.replace(RUN/'status.json')
try:
 for repeat in [1,2]:
  for variant in ['baseline','seed','candidate-03']:
   name=variant+'-r'+str(repeat);out=RUN/name;out.mkdir(parents=True,exist_ok=True)
   state['current']=name;save('开始布局布线 '+name)
   env=dict(os.environ,LD_LIBRARY_PATH=(ROOT/'physical/library-path.txt').read_text(),CHIP_LAB=str(ROOT),RUN_OUTPUT=str(out),DESIGN_VARIANT=variant)
   start=time.monotonic()
   with (out/'openroad.log').open('w') as f:
    p=subprocess.Popen([str(ROOT/'physical/toolchain/usr/bin/openroad'),'-exit',str(ROOT/'physical/flow.tcl')],env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
    while p.poll() is None:
     if time.monotonic()-start>600:os.killpg(p.pid,signal.SIGKILL);p.wait();break
     time.sleep(3);save()
   text=(out/'openroad.log').read_text();r={'variant':variant,'repeat':repeat,'name':name,'state':'failed','elapsed_s':round(time.monotonic()-start,2),'artifact':'physical/'+name+'/result.json'}
   try:
    if p.returncode!=0:raise ValueError('OpenROAD nonzero exit')
    if 'Found 0 unannotated drivers.' not in text or 'Found 0 partially unannotated drivers.' not in text:raise ValueError('Parasitics annotation incomplete')
    before=graph(ROOT/'runs/pilot-002'/variant/'mapped.v');after=graph(out/'routed.v')
    if not before['cells'] or before!=after:raise ValueError('Cell connectivity changed')
    violations=re.findall(r'Number of violations = (\d+)',text)
    if not violations:raise ValueError('Missing route DRC count')
    pre,post=text.split('MEASUREMENT_POST_ROUTE')
    pre=pre.split('MEASUREMENT_PRE_ROUTE')[1]
    delay=float(re.findall(r'([\d.]+)\s+data arrival time',post)[0]);unrouted=float(re.findall(r'([\d.]+)\s+data arrival time',pre)[0])
    area=json.loads((ROOT/'runs/pilot-002'/variant/'result.json').read_text())['area_um2']
    r.update(state='completed',delay_ns=delay,unrouted_same_tool_ns=unrouted,area_um2=area,adp=area*delay,cell_count=len(before['cells']),connectivity_unchanged=True,route_drc=int(violations[-1]),wire_length_um=int(re.findall(r'Total wire length = (\d+) um',text)[-1]),spef_sha256=hashlib.sha256((out/'routed.spef').read_bytes()).hexdigest())
   except Exception as e:r['reason']=str(e)
   (out/'result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));state['results'].append(r);state['completed']+=1;save('完成 '+name+' · '+r['state']);print(r,flush=True)
 state.update(state='completed' if all(r['state']=='completed' for r in state['results']) else 'failed',stage='review',current='');save('本轮物理验证结束')
except Exception as e:state.update(state='failed',reason=type(e).__name__);save('控制器中断');raise
