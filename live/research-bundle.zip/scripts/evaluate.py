"""Frozen evaluator: untrusted RTL runs in a networkless, filesystem-limited bubblewrap."""
import hashlib,json,os,re,resource,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
INPUTS=ROOT/'inputs'; TOOL=ROOT/'toolchain'

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(90,90))
 resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))
 resource.setrlimit(resource.RLIMIT_FSIZE,(40*1024**2,40*1024**2))

def run_tool(work,exe,args,name):
 cmd=['bwrap','--unshare-all','--die-with-parent','--new-session','--ro-bind','/usr','/usr','--ro-bind','/bin','/bin','--ro-bind','/lib','/lib','--ro-bind','/lib64','/lib64','--proc','/proc','--dev','/dev','--tmpfs','/tmp','--ro-bind',str(TOOL),'/toolchain','--ro-bind',str(INPUTS),'/inputs','--bind',str(work),'/work','--chdir','/work','--clearenv','--setenv','PATH','/toolchain/usr/bin:/usr/bin:/bin','--setenv','HOME','/tmp','--',exe]+args
 start=time.monotonic()
 try:
  r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=110,preexec_fn=limits)
  log=r.stdout; code=r.returncode
 except subprocess.TimeoutExpired as e:log=(e.stdout or b'').decode(errors='replace')+'\nWALL_TIMEOUT';code=124
 (work/(name+'.log')).write_text(log)
 return code,log,round(time.monotonic()-start,3)

def validate_rtl(source):
 if len(source)>60000:raise ValueError('RTL exceeds 60 KB')
 bare=re.sub(r'/\*.*?\*/|//[^\n]*','',source,flags=re.S)
 if re.search(r'`|\(\*|\b(?:initial|final|specify|force|release|tran|tranif|supply0|supply1)\b|#\s*\d|\$|\\',bare):raise ValueError('Unsupported directive, attribute, system call, escaped identifier or simulation construct')
 if re.search(r"\d*'[sS]?[bBoOdDhH][0-9a-fA-F_]*[xXzZ?]",bare):raise ValueError('Unknown/high-Z constants are forbidden')
 if not re.search(r'\bmodule\s+design\b',bare):raise ValueError('Missing design module')

SYNTH='''read_verilog candidate.v
hierarchy -check -top design
synth -top design -flatten -noabc
check -assert
abc -exe /toolchain/usr/bin/berkeley-abc -liberty /inputs/NangateOpenCellLibrary_typical.lib -constr /inputs/abc.constr
clean -purge
stat -liberty /inputs/NangateOpenCellLibrary_typical.lib
write_verilog -noattr mapped.v
write_json mapped.json
'''
FORMAL='''read_verilog /inputs/baseline.v
hierarchy -check -top design
proc
flatten
rename design gold
design -stash reference
read_verilog candidate.v
hierarchy -check -top design
proc
flatten
rename design gate
design -copy-from reference -as gold gold
miter -equiv -flatten gold gate miter
hierarchy -check -top miter
proc
opt
check -assert
sat -verify -prove trigger 0 -show-inputs -show-outputs miter
'''
STA='''read_liberty /inputs/NangateOpenCellLibrary_typical.lib
read_verilog mapped.v
link_design design
set_input_transition 0.020 [all_inputs]
set_load 5.0 [all_outputs]
create_clock -name virtual -period 10.0
set_input_delay 0 -clock virtual [all_inputs]
set_output_delay 0 -clock virtual [all_outputs]
set_max_delay 10.0 -from [all_inputs] -to [all_outputs]
check_setup
report_checks -path_delay max -format full_clock_expanded -digits 6 -group_count 1
exit
'''

def evaluate(work,source,baseline=False,stage=None):
 work=Path(work).resolve();work.mkdir(parents=True,exist_ok=True)
 (work/'candidate.v').write_text(source)
 result={'sha256':digest(work/'candidate.v'),'formal':'pending','status':'pending'}
 try:
  if not baseline:validate_rtl(source)
  if stage:stage('formal')
  (work/'formal.ys').write_text(FORMAL)
  code,log,t=run_tool(work,'/toolchain/usr/bin/yosys',['-s','formal.ys'],'formal')
  result['formal_seconds']=t
  if code or 'SAT proof finished - no model found: SUCCESS!' not in log:
   result.update(status='rejected',formal='fail',reason='Formal proof failed or was incomplete',diagnostic=log[-2400:]);return result
  result['formal']='pass'
  if stage:stage('synthesis')
  (work/'synth.ys').write_text(SYNTH)
  code,log,t=run_tool(work,'/toolchain/usr/bin/yosys',['-s','synth.ys'],'synthesis')
  result['synthesis_seconds']=t
  if code:raise RuntimeError('Synthesis failed: '+log[-1800:])
  net=json.loads((work/'mapped.json').read_text())['modules']['design']
  expected={'req':('input',64),'valid':('output',1),'index':('output',6),'grant':('output',64)}
  if {n:(v['direction'],len(v['bits'])) for n,v in net['ports'].items()}!=expected:raise ValueError('Port contract mismatch')
  if any(isinstance(b,str) and b in ('x','z') for v in net['ports'].values() for b in v['bits']):raise ValueError('Unknown output')
  cells=[v['type'] for v in net['cells'].values()]
  if not cells or any(c.startswith('$') or re.search(r'DFF|DFFE|DLH|DLL|LATCH',c,re.I) for c in cells):raise ValueError('Unmapped or sequential cells')
  matches=re.findall(r'Chip area for module[^\n:]+:\s*([\d.]+)',log)
  if len(matches)!=1:raise ValueError('Missing unique mapped area')
  area=float(matches[0]);result.update(area_um2=area,cells=len(cells))
  if stage:stage('timing')
  (work/'timing.tcl').write_text(STA)
  code,log,t=run_tool(work,'/toolchain/usr/bin/sta',['-exit','timing.tcl'],'timing')
  result['timing_seconds']=t
  if code or re.search(r'(^|\n)Error:',log):raise RuntimeError('STA failed: '+log[-1800:])
  vals=re.findall(r'^\s+([\d.]+)\s+data arrival time',log,re.M)
  if len(vals)!=1:raise ValueError('Missing unique maximum arrival time: '+log[-1800:])
  delay=float(vals[0])
  if not 0<area<100000 or not 0<delay<10:raise ValueError('Metric out of range')
  result.update(status='evaluated',delay_ns=delay,adp=round(area*delay,8))
 except Exception as e:result.update(status='rejected',reason=str(e)[:3000])
 return result

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('output');p.add_argument('--baseline',action='store_true');a=p.parse_args()
 result=evaluate(a.output,Path(a.source).read_text(),baseline=a.baseline)
 (Path(a.output)/'result.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(result,indent=2))
