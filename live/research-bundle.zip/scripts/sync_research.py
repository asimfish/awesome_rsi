"""Publish bounded research state and allowlisted worker counts, independently of Pages."""
from pathlib import Path
import argparse,base64,datetime,fcntl,json,os,subprocess,urllib.error
from sync_server import api
ROOT=Path(__file__).resolve().parents[1];KERNEL=ROOT.parent/'rsi-kernel-lab';STATE=ROOT/'monitoring';BRANCH='server-data'
def workers():
 parents={};groups={'chip':set(),'kernel':set()}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   stat=(p/'stat').read_text().rsplit(') ',1)[1].split();parents[int(p.name)]=(int(stat[1]),stat[0])
   if p.stat().st_uid!=os.getuid() or stat[0]=='Z':continue
   args=(p/'cmdline').read_bytes()[:8192].decode(errors='replace').split('\0')
   for arg in args[1:]:
    if Path(arg).name not in ['run_physical.py','run_research.py','evaluate_kernel.py']:continue
    path=Path(arg) if Path(arg).is_absolute() else Path(os.readlink(p/'cwd'))/arg
    for key,base in [('chip',ROOT),('kernel',KERNEL)]:
     if path.resolve().parent==base/'scripts':groups[key].add(int(p.name))
  except (OSError,ValueError,IndexError):continue
 for active in groups.values():
  for _ in range(12):
   kids={pid for pid,(parent,s) in parents.items() if parent in active and s!='Z'}
   if kids<=active:break
   active|=kids
 return {key:len(value) for key,value in groups.items()}
def snapshot():
 projects={}
 for key,path in [('chip',ROOT/'physical/runs/physical-002/status.json'),('kernel',KERNEL/'runs/kernel-002/status.json')]:
  s=json.loads(path.read_text())
  assert s['schema']==1 and s['project']==key and s['state'] in ['running','completed','failed']
  assert set(s)<=set('schema project run_id state started_at updated_at stage current completed planned results events scope method next selected reason'.split())
  projects[key]=s
 return {'schema':1,'published_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'interval_s':60,'stale_after_s':180,'workers':workers(),'projects':projects}
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--publish',action='store_true');a=parser.parse_args()
 with (STATE/'research.lock').open('w') as lock:
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:return
  data=snapshot();content=json.dumps(data,ensure_ascii=False,indent=2).encode();p=STATE/'research.tmp';p.write_bytes(content);p.replace(STATE/'research.json')
  if not a.publish:print('Research snapshot collected');return
  cred=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\n\n',capture_output=True,text=True,check=True,timeout=10,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'))
  token=dict(x.split('=',1) for x in cred.stdout.splitlines() if '=' in x)['password']
  try:old=api('/contents/research.json?ref='+BRANCH,token)
  except urllib.error.HTTPError as e:
   if e.code!=404:raise
   old={}
  if old.get('content'):
   previous=json.loads(base64.b64decode(old['content']));assert previous['schema']==1 and set(previous['projects'])=={'chip','kernel'}
  body={'message':'[research/data]: sync chip and kernel experiment state','branch':BRANCH,'content':base64.b64encode(content).decode()}
  if old.get('sha'):body['sha']=old['sha']
  api('/contents/research.json',token,'PUT',body);print('Research state published '+data['published_at'])
if __name__=='__main__':
 try:main()
 except Exception as e:print('Research sync failed: '+type(e).__name__);raise SystemExit(1)
