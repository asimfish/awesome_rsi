"""Researcher-authored mechanism probes; not autonomous RSI candidates."""
from evaluate import ROOT,evaluate
import json
for group in [2,4,8,16]:
 n=64//group;k=group.bit_length()-1
 s=['// Researcher-designed grouped direct-grant probe, separate from autonomous pilot.', 'module design(input wire [63:0] req, output wire valid, output wire [5:0] index, output wire [63:0] grant);',f'wire [{n-1}:0] gv, win;','assign valid=|req;']
 for g in range(n):
  s+=[f'assign gv[{g}]=|req[{g*group+group-1}:{g*group}];',f'assign win[{g}]=gv[{g}]'+(f' & ~(|gv[{n-1}:{g+1}]);' if g<n-1 else ';')]
 for i in range(64):
  if i==0:s+=['assign grant[0]=~(|req[63:1]);'];continue
  g=i//group;hi=(g+1)*group-1
  s+=[f'assign grant[{i}]=win[{g}] & req[{i}]'+(f' & ~(|req[{hi}:{i+1}]);' if i<hi else ';')]
 for b in range(6):
  if b>=k:terms=[f'win[{g}]' for g in range(n) if ((g<<k)>>b)&1]
  else:terms=[f'grant[{i}]' for i in range(64) if (i>>b)&1]
  s+=[f'assign index[{b}]='+' | '.join(terms)+';']
 s+=['endmodule'];source='\n'.join(s)+'\n';work=ROOT/f'runs/researcher-seed/group-{group}'
 result=evaluate(work,source);(work/'result.json').write_text(json.dumps(result,indent=2));print(group,result,flush=True)
