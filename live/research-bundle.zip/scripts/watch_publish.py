"""Publishes bounded worker progress; reports dead workers instead of simulating life."""
import argparse,json,os,time
from pathlib import Path
from datetime import datetime,timezone
from publish import ROOT,SITE,export,publish
p=argparse.ArgumentParser();p.add_argument('--pid',type=int,required=True);p.add_argument('--run',required=True);p.add_argument('--checkout',required=True);a=p.parse_args()
for tick in range(100):
 state=export(a.run)
 try:
  alive=Path(f'/proc/{a.pid}/stat').read_text().split()[2]!='Z'
 except FileNotFoundError:alive=False
 if state['state']=='running':
  if alive:state['heartbeat_at']=datetime.now(timezone.utc).isoformat()
  else:state.update(state='failed',stage='failed',monitor_note='Worker exited before writing a terminal state')
  for dest in [SITE/'live/status.json',SITE/'live/runs'/a.run/'status.json']:dest.write_text(json.dumps(state,ensure_ascii=False,indent=2))
 try:sha=publish(a.checkout,f'Update {a.run} evidence: {state["completed"]}/{state["budget"]} {state["stage"]}');print(sha,state['stage'],flush=True)
 except Exception as e:print('Publication failed:',type(e).__name__,flush=True);raise
 if state['state']!='running':break
 time.sleep(25)
else:raise SystemExit('Monitor reached 100-publication cap')
