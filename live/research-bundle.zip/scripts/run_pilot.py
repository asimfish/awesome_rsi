"""Bounded real-model optimization; no model-supplied commands are executed."""
import json,os,sys,time,hashlib,traceback
from pathlib import Path
import requests
from dotenv import dotenv_values
from evaluate import ROOT,INPUTS,digest,evaluate
RUN=ROOT/'runs/pilot-001';RUN.mkdir(parents=True,exist_ok=True)
STATE=RUN/'status.json'
def now():
 from datetime import datetime,timezone
 return datetime.now(timezone.utc).isoformat()
S={'schema':1,'run_id':'pilot-001','title':'64 路优先编码器 · RSI 优化','target':'verilog-axis / priority_encoder / WIDTH=64 / MSB first','state':'running','stage':'baseline','started_at':now(),'updated_at':now(),'budget':6,'completed':0,'api_calls':0,'tokens':{'prompt':0,'completion':0},'model':'deepseek-v4-pro','candidates':[],'events':[],'memory':[],'baseline':None,'best':None,'scope':'Nangate45 TT · 综合后、布局布线前 · 不含布线寄生与功耗','source_url':json.loads((INPUTS/'provenance.json').read_text())['priority_encoder.v']['url']}
def save():
 S['updated_at']=now();tmp=STATE.with_suffix('.tmp');tmp.write_text(json.dumps(S,ensure_ascii=False,indent=2));tmp.replace(STATE)
def event(stage,text):
 S['stage']=stage;S['events'].append({'at':now(),'stage':stage,'text':text});save();print(text,flush=True)
def api(messages,max_tokens):
 if S['api_calls']>=12:raise RuntimeError('API call budget exhausted')
 S['api_calls']+=1;save()
 r=requests.post('https://api.deepseek.com/chat/completions',headers={'Authorization':'Bearer '+KEY},json={'model':S['model'],'messages':messages,'temperature':0.6,'max_tokens':max_tokens,'thinking':{'type':'disabled'},'response_format':{'type':'json_object'}},timeout=(15,180))
 if r.status_code!=200:raise RuntimeError('Model API HTTP '+str(r.status_code))
 d=r.json();usage=d.get('usage',{});S['tokens']['prompt']+=usage.get('prompt_tokens',0);S['tokens']['completion']+=usage.get('completion_tokens',0);save()
 if d['choices'][0].get('finish_reason')!='stop':raise ValueError('Model output incomplete')
 return d['choices'][0]['message']['content'],usage

def main():
 global KEY
 cfg=dotenv_values('/home/liyufeng/super_translate/.env')
 KEY=os.getenv('DEEPSEEK_API_KEY') or cfg.get('PAPER_CHINA_DEEPSEEK_API_KEY') or cfg.get('DEEPSEEK_API_KEY')
 if not KEY:raise RuntimeError('No DeepSeek API credential available')
 manifest={'protocol':'pilot-001-v1','model':S['model'],'input_hashes':{p.name:digest(p) for p in INPUTS.iterdir() if p.is_file()},'evaluator_sha256':digest(Path(__file__).with_name('evaluate.py')),'tools':{'yosys':'0.9 / 1979e0b','abc':'Ubuntu 1.01+20211229git48498af+dfsg-2','opensta':'2.0.17 / c018cb2'},'constraints':{'input_slew_ns':0.020,'output_load_ff':5,'corner':'TT 1.1V 25C','parasitics':'none','ABC_driving_cell':'BUF_X1'},'selection':{'min_adp_improvement':0.01,'max_delay_vs_original':1.05},'max_candidates':6,'max_api_requests':12}
 (RUN/'manifest.json').write_text(json.dumps(manifest,indent=2))
 base=evaluate(RUN/'baseline',(INPUTS/'baseline.v').read_text(),baseline=True)
 (RUN/'baseline/result.json').write_text(json.dumps(base,indent=2))
 if base['status']!='evaluated':raise RuntimeError('Baseline failed: '+base.get('reason',''))
 base.update(id='baseline',label='原始开源基线');S['baseline']=base;S['best']=base
 best_source=(INPUTS/'baseline.v').read_text();save()
 event('baseline','基线完成：面积 %.3f µm²，延迟 %.6f ns；形式等价通过。'%(base['area_um2'],base['delay_ns']))
 for n in range(1,7):
  cid=f'candidate-{n:02}';work=RUN/cid;work.mkdir(exist_ok=True)
  for p,h in manifest['input_hashes'].items():
   if digest(INPUTS/p)!=h:raise RuntimeError('Frozen input changed')
  if digest(Path(__file__).with_name('evaluate.py'))!=manifest['evaluator_sha256']:raise RuntimeError('Evaluator changed during run')
  event('generating',f'候选 {n}/6：模型读取当前优胜与 {len(S["memory"])} 条经验，生成等价 RTL。')
  instructions='''You optimize real combinational Verilog for Nangate45 standard cells. Return JSON with keys rationale (short Chinese), strategy (short), verilog (complete source). Implement exactly module design(input wire [63:0] req, output wire valid, output wire [5:0] index, output wire [63:0] grant). Highest set bit has priority. valid=|req. index=highest set bit index, or 0 if req=0. grant is 1<<index INCLUDING when req=0 (grant=1). All outputs are checked for every possible 64-bit input by SAT. No don't-cares, x/z, directives, attributes, system calls, latches, clocks, initial blocks or external modules. Use Verilog-2005 synthesizable combinational logic and constant-bound generate loops. Preserve the license if copying reference code. Propose a substantively different implementation informed by measured evidence. Objective: lower mapped area*worst delay; delay <= original baseline*1.05. Advancement requires >=1% ADP reduction against current best. ABC already performs strong logic optimization; avoid merely renaming. Think about one-hot grants, parallel prefix/grouped detection, and encoding fanout. Fixed Yosys 0.9/ABC maps to Nangate45 TT, STA 20ps input slew/5fF load, no wire parasitics. You cannot change evaluator/constraints. This is one sequential memory-guided search, not proof of general RSI.'''
  payload={'round':n,'baseline':base,'current_best':S['best'],'best_verilog':best_source,'memory':S['memory'],'past_results':[{k:v for k,v in c.items() if k not in ('diagnostic',)} for c in S['candidates']]}
  messages=[{'role':'system','content':instructions},{'role':'user','content':json.dumps(payload,ensure_ascii=False)}]
  (work/'prompt.json').write_text(json.dumps(messages,ensure_ascii=False,indent=2))
  try:
   raw,usage=api(messages,6000);(work/'response.json').write_text(raw);obj=json.loads(raw)
   if not isinstance(obj.get('verilog'),str):raise ValueError('Missing Verilog string')
   result=evaluate(work,obj['verilog'],stage=lambda st:event(st,f'候选 {n}/6：'+{'formal':'检查所有输入的功能等价','synthesis':'综合并映射标准单元','timing':'计算最坏路径延迟'}[st]))
   result.update(id=cid,rationale=str(obj.get('rationale',''))[:1200],strategy=str(obj.get('strategy',''))[:300],usage=usage)
  except (ValueError,requests.Timeout) as e:
   result={'id':cid,'status':'rejected','formal':'not_proven','reason':type(e).__name__+': '+str(e)[:300]}
  accepted=result['status']=='evaluated' and result['delay_ns']<=base['delay_ns']*1.05 and result['adp']<=S['best']['adp']*.99
  result['accepted']=accepted;result['parent']=S['best']['id']
  if result['status']=='evaluated':
   result['adp_gain_pct']=round(100*(1-result['adp']/base['adp']),3)
   result['area_gain_pct']=round(100*(1-result['area_um2']/base['area_um2']),3)
   result['delay_gain_pct']=round(100*(1-result['delay_ns']/base['delay_ns']),3)
  if accepted:S['best']=result.copy();best_source=(work/'candidate.v').read_text()
  S['candidates'].append(result);S['completed']=n
  (work/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
  event('selection',f'候选 {n}/6：'+('晋升为当前优胜。' if accepted else '未晋升，保留当前优胜。')+(f' ADP 相对原始基线改善 {result["adp_gain_pct"]:.2f}%。' if 'adp_gain_pct' in result else result.get('reason','')))
  event('learning',f'候选 {n}/6：根据真实验证结果提炼经验。')
  reflection=[{'role':'system','content':'Return JSON {"lesson": "..."}. Write one short evidence-grounded Chinese optimization lesson from the actual result. Mention mechanism, measured tradeoff or failure and a next-action recommendation. No invented measurements; distinguish hypotheses. This text will guide the next candidate.'},{'role':'user','content':json.dumps({'result':result,'best':S['best'],'previous_memory':S['memory']},ensure_ascii=False)}]
  (work/'reflection-prompt.json').write_text(json.dumps(reflection,ensure_ascii=False,indent=2))
  try:
   raw,_=api(reflection,600);(work/'reflection.json').write_text(raw);lesson=json.loads(raw)['lesson']
   if not isinstance(lesson,str):raise ValueError('Invalid lesson')
   S['memory'].append({'version':n,'from_candidate':cid,'lesson':lesson[:1800]})
  except (ValueError,requests.Timeout):S['memory'].append({'version':n,'from_candidate':cid,'lesson':'经验提炼失败，仅保留结构化测量；不推断优化规律。'})
  (RUN/'memory.json').write_text(json.dumps(S['memory'],ensure_ascii=False,indent=2));save()
 event('revalidation','候选预算已用完，独立重跑当前优胜。')
 best_dir=RUN/'revalidation';recheck=evaluate(best_dir,best_source,baseline=S['best']['id']=='baseline')
 (best_dir/'result.json').write_text(json.dumps(recheck,indent=2))
 ok=recheck['status']=='evaluated' and all(abs(recheck[k]-S['best'][k])<1e-8 for k in ['area_um2','delay_ns','adp'])
 S['revalidation']={'pass':ok,'result':recheck}
 if not ok:raise RuntimeError('Winner revalidation failed or metrics changed')
 (RUN/'best.v').write_text(best_source)
 S['state']='completed';S['finished_at']=now();event('completed',f'首轮实验结束：6 个候选已评估，优胜 {S["best"]["id"]} 已独立复跑。')

if __name__=='__main__':
 try:main()
 except Exception as e:
  S['state']='failed';S['finished_at']=now();event('failed',type(e).__name__+': '+str(e)[:800]);raise
