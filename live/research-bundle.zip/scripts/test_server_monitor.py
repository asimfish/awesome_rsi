import json,subprocess,unittest
from unittest.mock import patch
import collect_server as c
from sync_server import validate
class ServerTests(unittest.TestCase):
 def test_gpu_missing_is_unknown_not_idle(self):
  with patch.object(c.shutil,'which',return_value=None):self.assertEqual(c.gpu_metrics(set())['status'],'unavailable')
 def test_gpu_failure_is_unknown_not_zero(self):
  with patch.object(c.shutil,'which',return_value='/usr/bin/nvidia-smi'),patch.object(c.subprocess,'run',return_value=subprocess.CompletedProcess([],1,'','error')):
   self.assertEqual(c.gpu_metrics(set())['cards'],[])
 def test_per_gpu_process_ownership_and_no_identifiers(self):
  responses=[subprocess.CompletedProcess([],0,'0, GPU-private-id, Test GPU, 50, 4096, 8192, 60, 100, 250\n',''),subprocess.CompletedProcess([],0,'GPU-private-id, 123, 2048\nGPU-private-id, 456, 2048\n','')]
  with patch.object(c.shutil,'which',return_value='/usr/bin/nvidia-smi'),patch.object(c.subprocess,'run',side_effect=responses):result=c.gpu_metrics({123})
  card=result['cards'][0];self.assertEqual(card['project_compute_processes'],1);self.assertEqual(card['other_compute_processes'],1)
  self.assertNotIn('private-id',json.dumps(result));self.assertNotIn('pid',json.dumps(result));self.assertNotIn('uuid',json.dumps(result))
 def test_process_visibility_failure_remains_unknown(self):
  responses=[subprocess.CompletedProcess([],0,'0, GPU-private-id, Test GPU, N/A, 4096, 8192, N/A, N/A, 250\n',''),subprocess.CompletedProcess([],1,'','')]
  with patch.object(c.shutil,'which',return_value='/usr/bin/nvidia-smi'),patch.object(c.subprocess,'run',side_effect=responses):card=c.gpu_metrics(set())['cards'][0]
  self.assertIsNone(card['util_pct']);self.assertIsNone(card['other_compute_processes'])
 def test_real_public_schema_excludes_private_fields(self):
  s=json.loads((c.ROOT/'monitoring/servers.json').read_text());validate(s)
  forbidden={'pid','ppid','uuid','hostname','ip','cmdline','environment','username','cwd','mountpoint','token','password'}
  def walk(x):
   if isinstance(x,dict):
    self.assertFalse(forbidden&set(x));[walk(v) for v in x.values()]
   elif isinstance(x,list):[walk(v) for v in x]
  walk(s)
if __name__=='__main__':unittest.main()
