"""Publish explicit public artifacts only. Never copies credentials or toolchain binaries."""
from pathlib import Path
import json,shutil,subprocess,zipfile,argparse,hashlib,re
ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT.parent/'awesome_RSI/report/chip-rsi'
ALLOWED={'candidate.v','formal.log','synthesis.log','timing.log','mapped.v','mapped.json','formal.ys','synth.ys','timing.tcl','result.json','prompt.json','response.json','reflection.json','reflection-prompt.json','manifest.json','memory.json','best.v','controls.json','audit.json','status.json','mapped-formal.ys','mapped-formal.log','mapped-proof.json'}
def export(run_id):
 run=ROOT/'runs'/run_id
 state=json.loads((run/'status.json').read_text())
 live=SITE/'live';archive=live/'runs'/run_id;archive.mkdir(parents=True,exist_ok=True)
 (archive/'status.json').write_text(json.dumps(state,ensure_ascii=False,indent=2))
 artifacts=archive/'artifacts';artifacts.mkdir(exist_ok=True)
 for p in run.rglob('*'):
  if p.is_file() and p.name in ALLOWED:
   d=artifacts/p.relative_to(run);d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
 (live/'status.json').write_text(json.dumps(state,ensure_ascii=False,indent=2))
 shutil.copyfile(ROOT/'GOAL.md',live/'protocol.md')
 shutil.copyfile(run/'manifest.json',live/'manifest.json')
 with zipfile.ZipFile(live/'research-bundle.zip','w',zipfile.ZIP_DEFLATED) as z:
  for folder in ['scripts','refine-logs']:
   for p in (ROOT/folder).rglob('*'):
    if p.is_file() and p.suffix in ['.py','.md']:z.write(p,p.relative_to(ROOT))
  for p in (ROOT/'runs').rglob('*'):
   if p.is_file() and p.name in ALLOWED:z.write(p,p.relative_to(ROOT))
  for name in ['baseline.v','priority_encoder.v','COPYING','abc.constr','provenance.json']:
   z.write(ROOT/'inputs'/name,'inputs/'+name)
  z.write(ROOT/'toolchain/packages/sha256.json','toolchain/packages/sha256.json')
  for name in ['README.md','silicon-loop-server.service','silicon-loop-server.timer']:
   p=ROOT/'monitoring'/name
   if p.exists():z.write(p,'monitoring/'+name)
  for name in ['README.md','GOAL.md']:
   if (ROOT/name).exists():z.write(ROOT/name,name)
 return state

def publish(checkout,message,prepare_only=False):
 dest=Path(checkout)
 for name in ['assets','live','README.md','research.md']:
  p=SITE/name
  if p.is_dir():shutil.copytree(p,dest/name,dirs_exist_ok=True)
  else:shutil.copyfile(p,dest/name)
 shutil.copyfile(SITE/'index.html',dest/'scenes.html')
 # Root index belongs to the RSI reading site; update the chip topic separately.
 chip=dest/'chip';chip.mkdir(exist_ok=True)
 existing_chip=(chip/'index.html').read_text() if (chip/'index.html').exists() else ''
 return_nav=re.search(r'<nav\b[^>]*\bdata-rsi-return="true"[^>]*>[\s\S]*?</nav>',existing_chip)
 for name in ['index.html','assets','live','data','experiments','README.md','research.md']:
  p=SITE/name
  if p.is_dir():shutil.copytree(p,chip/name,dirs_exist_ok=True)
  else:shutil.copyfile(p,chip/name)
 shutil.copyfile(SITE/'index.html',chip/'scenes.html')
 if return_nav:
  for name in ['index.html','scenes.html']:
   p=chip/name;p.write_text(p.read_text().replace('<body>','<body>'+return_nav[0],1))
 rp=dest/'research.md';rp.write_text(rp.read_text().replace('../../reports/','https://github.com/asimfish/awesome_rsi/blob/main/reports/'))
 rp=chip/'research.md';rp.write_text(rp.read_text().replace('../../reports/','https://github.com/asimfish/awesome_rsi/blob/main/reports/'))
 subprocess.run(['git','-C',str(dest),'add','scenes.html','assets','live','README.md','research.md','chip'],check=True)
 if prepare_only:return 'Prepared and staged public artifacts; no commit or push.'
 if subprocess.run(['git','-C',str(dest),'diff','--cached','--quiet']).returncode:
  subprocess.run(['git','-C',str(dest),'commit','-m',message],check=True,stdout=subprocess.DEVNULL)
  subprocess.run(['git','-C',str(dest),'push','origin','gh-pages'],check=True)
 return subprocess.check_output(['git','-C',str(dest),'rev-parse','HEAD'],text=True).strip()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--run',default='pilot-001');p.add_argument('--checkout');p.add_argument('--message',default='Publish measured RTL optimization progress');p.add_argument('--prepare-only',action='store_true');a=p.parse_args()
 s=export(a.run);print({'run':a.run,'state':s['state'],'completed':s['completed']})
 if a.checkout:print(publish(a.checkout,a.message,a.prepare_only))
