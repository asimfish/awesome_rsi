# Silicon Loop：真实 RTL 优化研究

运行网站：https://asimfish.github.io/awesome_rsi/scenes.html#live

目标是通过 RTL 改写、全输入形式等价、综合/时序评估、反馈与经验复用改善实际模块。
开源工程参考：[RTLScout](https://github.com/huawei-csl/rtlscout) 的 correctness → cost → retain 框架；本仓库的实验控制器为本次独立编写，不是 RTLScout / Dr. RTL 论文结果复现。

## 当前实验

- `pilot-001`：6 个模型候选，从真实原始实现开始，未发现改进。保留所有失败；`audit.json` 记录过滤器缺陷和模型反思的事实错误。
- `researcher-seed`：9 个研究者设计的机制探针。它们不算自主模型发现。
- `pilot-002`：修正过滤器，使用研究者的 4 位分组种子，4 个模型候选；仅将程序生成的测量事实回流。研究者提供种子的收益单列。

### 固定口径

MIT verilog-axis priority_encoder，WIDTH=64，MSB 高优先级，原始 commit 见 inputs/provenance.json。
输入全零时 grant=1、index=0。这些输出不是 don't-care。
Yosys 0.9 / ABC 20211229 / OpenSTA 2.0.17；Nangate45 TT 1.1 V 25°C，20 ps 输入转换、5 fF 输出负载。
面积是映射标准单元总面积。时序是布局布线前、无寄生的最坏组合路径。不测功耗、不报告流片/工业 PPA 改善。
晋升：形式通过、ADP 比当前优胜至少低 1%，延迟不超过原始基线 105%。

## 复跑测量（Ubuntu 22.04 / Linux）

需要 Python 3、bubblewrap、libtcl8.6、libreadline8，以及解包工具 dpkg-deb。

```bash
mkdir -p toolchain/packages
cd toolchain/packages
apt-get download yosys=0.9-2 berkeley-abc=1.01+20211229git48498af+dfsg-2 opensta=0~20191111gitc018cb2+dfsg-1build1
cd ../..
python3 scripts/bootstrap.py
python3 scripts/evaluate.py inputs/baseline.v /tmp/silicon-baseline --baseline
python3 scripts/evaluate.py runs/pilot-002/seed/candidate.v /tmp/silicon-seed
# Researcher hybrid source retains upstream compiler directives; trusted reference path:
python3 scripts/evaluate.py runs/researcher-seed/hybrid-8/candidate.v /tmp/silicon-hybrid --baseline
python3 scripts/test_validator.py
```

`--baseline` 只跳过模型文本输入过滤，仍做正式等价证明、端口契约、综合、时序和结果检查。不要对不信任的输入跳过过滤。
工具在 bubblewrap 的独立网络命名空间中运行，只读工具链/参考库，仅候选目录可写；不挂载用户 home 与 API 凭据。

所有复跑输出应放在新目录，避免覆盖已归档实验。
首轮可用 scripts/evaluate_v1.py 重现旧过滤行为；每轮 manifest.json 固定评估器与输入 SHA-256。
liberty 从固定官方源码 URL 下载，本归档不重新分发该库；芯片源文件的 MIT 声明随文件保留。

## 模型研究与公开进度

模型实际使用 DeepSeek API，模型为 deepseek-v4-pro，温度 0.6。每次候选最多 6000 输出 token、反思最多 600；首轮 12 次请求，第二轮最多 8 次。无 API 自动重试。
模型反思是未经独立核实的文本；首轮存在符号错误。第二轮归档原文，但后续只读取测量生成的事实和候选策略标签。
这两个单轨迹实验尚未证明记忆机制优于无记忆搜索，也没有更新模型权重。

`publish.py` 通过显式文件白名单导出证据，`watch_publish.py` 读取实际进程状态，每约 25 秒提交公开记录；GitHub 缓存与构建还会增加延迟，浏览器每 30 秒读取。
任务终止后发布 terminal state；超过 180 秒未收到运行心跳显示过期。本站没有假进度条，也不在浏览器中执行 EDA。

不自动复跑已经结束的模型实验；新的预算与协议写入独立 run ID。当前控制器脚本用于归档复现，已有 run 目录禁止覆盖。
