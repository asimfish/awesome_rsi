/*

Copyright (c) 2014-2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001

`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * Priority encoder module
 */
module priority_encoder #
(
    parameter WIDTH = 4,
    // LSB priority selection
    parameter LSB_HIGH_PRIORITY = 0
)
(
    input  wire [WIDTH-1:0]         input_unencoded,
    output wire                     output_valid,
    output wire [$clog2(WIDTH)-1:0] output_encoded,
    output wire [WIDTH-1:0]         output_unencoded
);

parameter LEVELS = WIDTH > 2 ? $clog2(WIDTH) : 1;
parameter W = 2**LEVELS;

// pad input to even power of two
wire [W-1:0] input_padded = {{W-WIDTH{1'b0}}, input_unencoded};

wire [W/2-1:0] stage_valid[LEVELS-1:0];
wire [W/2-1:0] stage_enc[LEVELS-1:0];

generate
    genvar l, n;

    // process input bits; generate valid bit and encoded bit for each pair
    for (n = 0; n < W/2; n = n + 1) begin : loop_in
        assign stage_valid[0][n] = |input_padded[n*2+1:n*2];
        if (LSB_HIGH_PRIORITY) begin
            // bit 0 is highest priority
            assign stage_enc[0][n] = !input_padded[n*2+0];
        end else begin
            // bit 0 is lowest priority
            assign stage_enc[0][n] = input_padded[n*2+1];
        end
    end

    // compress down to single valid bit and encoded bus
    for (l = 1; l < LEVELS; l = l + 1) begin : loop_levels
        for (n = 0; n < W/(2*2**l); n = n + 1) begin : loop_compress
            assign stage_valid[l][n] = |stage_valid[l-1][n*2+1:n*2];
            if (LSB_HIGH_PRIORITY) begin
                // bit 0 is highest priority
                assign stage_enc[l][(n+1)*(l+1)-1:n*(l+1)] = stage_valid[l-1][n*2+0] ? {1'b0, stage_enc[l-1][(n*2+1)*l-1:(n*2+0)*l]} : {1'b1, stage_enc[l-1][(n*2+2)*l-1:(n*2+1)*l]};
            end else begin
                // bit 0 is lowest priority
                assign stage_enc[l][(n+1)*(l+1)-1:n*(l+1)] = stage_valid[l-1][n*2+1] ? {1'b1, stage_enc[l-1][(n*2+2)*l-1:(n*2+1)*l]} : {1'b0, stage_enc[l-1][(n*2+1)*l-1:(n*2+0)*l]};
            end
        end
    end
endgenerate

assign output_valid = stage_valid[LEVELS-1];
assign output_encoded = stage_enc[LEVELS-1];
assign output_unencoded=0;
endmodule
module design(input wire [63:0] req, output wire valid, output wire [5:0] index, output wire [63:0] grant);
priority_encoder #(.WIDTH(64),.LSB_HIGH_PRIORITY(0)) dut(.input_unencoded(req),.output_valid(valid),.output_encoded(index),.output_unencoded());
assign grant[0]=1'b1 & ~(|req[63:1]);
assign grant[1]=req[1] & ~(|req[63:2]);
assign grant[2]=req[2] & ~(|req[63:3]);
assign grant[3]=req[3] & ~(|req[63:4]);
assign grant[4]=req[4] & ~(|req[63:5]);
assign grant[5]=req[5] & ~(|req[63:6]);
assign grant[6]=req[6] & ~(|req[63:7]);
assign grant[7]=req[7] & ~(|req[63:8]);
assign grant[8]=req[8] & ~(|req[63:9]);
assign grant[9]=req[9] & ~(|req[63:10]);
assign grant[10]=req[10] & ~(|req[63:11]);
assign grant[11]=req[11] & ~(|req[63:12]);
assign grant[12]=req[12] & ~(|req[63:13]);
assign grant[13]=req[13] & ~(|req[63:14]);
assign grant[14]=req[14] & ~(|req[63:15]);
assign grant[15]=req[15] & ~(|req[63:16]);
assign grant[16]=req[16] & ~(|req[63:17]);
assign grant[17]=req[17] & ~(|req[63:18]);
assign grant[18]=req[18] & ~(|req[63:19]);
assign grant[19]=req[19] & ~(|req[63:20]);
assign grant[20]=req[20] & ~(|req[63:21]);
assign grant[21]=req[21] & ~(|req[63:22]);
assign grant[22]=req[22] & ~(|req[63:23]);
assign grant[23]=req[23] & ~(|req[63:24]);
assign grant[24]=req[24] & ~(|req[63:25]);
assign grant[25]=req[25] & ~(|req[63:26]);
assign grant[26]=req[26] & ~(|req[63:27]);
assign grant[27]=req[27] & ~(|req[63:28]);
assign grant[28]=req[28] & ~(|req[63:29]);
assign grant[29]=req[29] & ~(|req[63:30]);
assign grant[30]=req[30] & ~(|req[63:31]);
assign grant[31]=req[31] & ~(|req[63:32]);
assign grant[32]=req[32] & ~(|req[63:33]);
assign grant[33]=req[33] & ~(|req[63:34]);
assign grant[34]=req[34] & ~(|req[63:35]);
assign grant[35]=req[35] & ~(|req[63:36]);
assign grant[36]=req[36] & ~(|req[63:37]);
assign grant[37]=req[37] & ~(|req[63:38]);
assign grant[38]=req[38] & ~(|req[63:39]);
assign grant[39]=req[39] & ~(|req[63:40]);
assign grant[40]=req[40] & ~(|req[63:41]);
assign grant[41]=req[41] & ~(|req[63:42]);
assign grant[42]=req[42] & ~(|req[63:43]);
assign grant[43]=req[43] & ~(|req[63:44]);
assign grant[44]=req[44] & ~(|req[63:45]);
assign grant[45]=req[45] & ~(|req[63:46]);
assign grant[46]=req[46] & ~(|req[63:47]);
assign grant[47]=req[47] & ~(|req[63:48]);
assign grant[48]=req[48] & ~(|req[63:49]);
assign grant[49]=req[49] & ~(|req[63:50]);
assign grant[50]=req[50] & ~(|req[63:51]);
assign grant[51]=req[51] & ~(|req[63:52]);
assign grant[52]=req[52] & ~(|req[63:53]);
assign grant[53]=req[53] & ~(|req[63:54]);
assign grant[54]=req[54] & ~(|req[63:55]);
assign grant[55]=req[55] & ~(|req[63:56]);
assign grant[56]=req[56] & ~(|req[63:57]);
assign grant[57]=req[57] & ~(|req[63:58]);
assign grant[58]=req[58] & ~(|req[63:59]);
assign grant[59]=req[59] & ~(|req[63:60]);
assign grant[60]=req[60] & ~(|req[63:61]);
assign grant[61]=req[61] & ~(|req[63:62]);
assign grant[62]=req[62] & ~(|req[63:63]);
assign grant[63]=req[63];
endmodule
